import { useState, useEffect, useRef } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'

// Mock JWT functions - in a real app, these would call your backend
const mockAuthAPI = {
  login: async (email, password) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (email && password) {
      // In real app, this would come from your backend
      const token = btoa(JSON.stringify({
        userId: 1,
        email: email,
        exp: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
      }));
      return { success: true, token };
    }
    return { success: false, error: 'Invalid credentials' };
  },

  register: async (name, email, password) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (name && email && password) {
      const token = btoa(JSON.stringify({
        userId: Date.now(),
        name: name,
        email: email,
        exp: Date.now() + (24 * 60 * 60 * 1000)
      }));
      return { success: true, token };
    }
    return { success: false, error: 'Registration failed' };
  },

  verifyToken: (token) => {
    try {
      const decoded = JSON.parse(atob(token));
      return decoded.exp > Date.now();
    } catch {
      return false;
    }
  }
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [medicines, setMedicines] = useState([]);
  const [showAddMedicine, setShowAddMedicine] = useState(false);
  const [loading, setLoading] = useState(false);
  const [authError, setAuthError] = useState('');
  
  // Use refs for form inputs
  const nameRef = useRef(null);
  const dosageRef = useRef(null);
  const frequencyRef = useRef(null);
  const timeRef = useRef(null);
  const loginEmailRef = useRef(null);
  const loginPasswordRef = useRef(null);
  const registerNameRef = useRef(null);
  const registerEmailRef = useRef(null);
  const registerPasswordRef = useRef(null);

  // Check if user is already logged in with valid token
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token && mockAuthAPI.verifyToken(token)) {
      setIsAuthenticated(true);
      // Load saved medicines
      const savedMedicines = localStorage.getItem('medicines');
      if (savedMedicines) {
        setMedicines(JSON.parse(savedMedicines));
      }
    } else {
      // Token is invalid or expired
      localStorage.removeItem('token');
      localStorage.removeItem('medicines');
    }
  }, []);

  // Login handler with JWT
  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setAuthError('');

    const email = loginEmailRef.current?.value;
    const password = loginPasswordRef.current?.value;

    try {
      const result = await mockAuthAPI.login(email, password);
      
      if (result.success) {
        // Store JWT token
        localStorage.setItem('token', result.token);
        setIsAuthenticated(true);
      } else {
        setAuthError(result.error || 'Login failed');
      }
    } catch (error) {
      setAuthError('Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Register handler with JWT
  const handleRegister = async (e) => {
    e.preventDefault();
    setLoading(true);
    setAuthError('');

    const name = registerNameRef.current?.value;
    const email = registerEmailRef.current?.value;
    const password = registerPasswordRef.current?.value;

    try {
      const result = await mockAuthAPI.register(name, email, password);
      
      if (result.success) {
        // Store JWT token
        localStorage.setItem('token', result.token);
        setIsAuthenticated(true);
      } else {
        setAuthError(result.error || 'Registration failed');
      }
    } catch (error) {
      setAuthError('Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // Logout handler
  const handleLogout = () => {
    // Clear all stored data
    localStorage.removeItem('token');
    localStorage.removeItem('medicines');
    setIsAuthenticated(false);
    setMedicines([]);
    setAuthError('');
  };

  // Open modal handler
  const handleOpenModal = () => {
    setShowAddMedicine(true);
    // Clear inputs when opening modal
    setTimeout(() => {
      if (nameRef.current) nameRef.current.value = '';
      if (dosageRef.current) dosageRef.current.value = '';
      if (frequencyRef.current) frequencyRef.current.value = '';
      if (timeRef.current) timeRef.current.value = '';
    }, 0);
  };

  // Add medicine handler
  const handleAddMedicine = () => {
    const name = nameRef.current?.value || '';
    const dosage = dosageRef.current?.value || '';
    const frequency = frequencyRef.current?.value || '';
    const time = timeRef.current?.value || '';

    if (!name || !dosage || !frequency || !time) {
      alert('Please fill all fields');
      return;
    }
    
    const medicine = {
      id: Date.now(),
      name,
      dosage,
      frequency,
      time,
      lastTaken: 'Never'
    };
    
    const updatedMedicines = [...medicines, medicine];
    setMedicines(updatedMedicines);
    localStorage.setItem('medicines', JSON.stringify(updatedMedicines));
    setShowAddMedicine(false);
  };

  // Close modal handler
  const handleCloseModal = () => {
    setShowAddMedicine(false);
  };

  // Mark as taken handler
  const handleMarkAsTaken = (id) => {
    const updatedMedicines = medicines.map(med => 
      med.id === id ? { ...med, lastTaken: new Date().toLocaleString() } : med
    );
    setMedicines(updatedMedicines);
    localStorage.setItem('medicines', JSON.stringify(updatedMedicines));
  };

  // Delete medicine handler
  const handleDeleteMedicine = (id) => {
    const updatedMedicines = medicines.filter(med => med.id !== id);
    setMedicines(updatedMedicines);
    localStorage.setItem('medicines', JSON.stringify(updatedMedicines));
  };

  // Login Form
  const LoginForm = () => (
    <div className="login-container">
      <div className="form-wrapper">
        <div className="dosebuddy-card card shadow">
          <div className="card-body p-5">
            <h1 className="dosebuddy-title">DoseBuddy</h1>
            <p className="dosebuddy-subtitle">Your Personal Medication Manager</p>
            
            {authError && (
              <div className="alert alert-danger" role="alert">
                {authError}
              </div>
            )}
            
            <form onSubmit={handleLogin} className="dosebuddy-form">
              <div className="form-group">
                <label htmlFor="email" className="form-label">Email</label>
                <input 
                  ref={loginEmailRef}
                  type="email" 
                  className="form-control" 
                  id="email" 
                  placeholder="Enter your email"
                  required 
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="password" className="form-label">Password</label>
                <input 
                  ref={loginPasswordRef}
                  type="password" 
                  className="form-control" 
                  id="password" 
                  placeholder="Enter your password"
                  required 
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <button 
                  type="submit" 
                  className="dosebuddy-btn-primary btn w-100 mb-3"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                      Signing In...
                    </>
                  ) : (
                    'Sign In'
                  )}
                </button>
              </div>
            </form>

            <div className="text-center">
              <p className="mb-0">Don't have an account?</p>
              <button 
                className="btn btn-link p-0 create-account-btn" 
                onClick={() => setShowRegister(true)}
                disabled={loading}
              >
                Create Account
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Register Form
  const RegisterForm = () => (
    <div className="login-container">
      <div className="form-wrapper">
        <div className="dosebuddy-card card shadow">
          <div className="card-body p-5">
            <h1 className="dosebuddy-title">DoseBuddy</h1>
            <p className="dosebuddy-subtitle">Create Your Account</p>
            
            {authError && (
              <div className="alert alert-danger" role="alert">
                {authError}
              </div>
            )}
            
            <form onSubmit={handleRegister} className="dosebuddy-form">
              <div className="form-group">
                <label htmlFor="name" className="form-label">Full Name</label>
                <input 
                  ref={registerNameRef}
                  type="text" 
                  className="form-control" 
                  id="name" 
                  placeholder="Enter your full name"
                  required 
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="regEmail" className="form-label">Email</label>
                <input 
                  ref={registerEmailRef}
                  type="email" 
                  className="form-control" 
                  id="regEmail" 
                  placeholder="Enter your email"
                  required 
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <label htmlFor="regPassword" className="form-label">Password</label>
                <input 
                  ref={registerPasswordRef}
                  type="password" 
                  className="form-control" 
                  id="regPassword" 
                  placeholder="Create a password"
                  required 
                  disabled={loading}
                />
              </div>
              <div className="form-group">
                <button 
                  type="submit" 
                  className="dosebuddy-btn-primary btn w-100 mb-3"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                      Creating Account...
                    </>
                  ) : (
                    'Create Account'
                  )}
                </button>
              </div>
            </form>

            <div className="text-center">
              <p className="mb-0">Already have an account?</p>
              <button 
                className="btn btn-link p-0" 
                onClick={() => setShowRegister(false)}
                disabled={loading}
              >
                Sign In
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Dashboard
  const Dashboard = () => (
    <div className="dashboard-container w-100">
      <div className="dashboard-header">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <div>
            <h1 className="dosebuddy-title">DoseBuddy</h1>
            <p className="dosebuddy-subtitle">Manage Your Medications</p>
          </div>
          <button 
            className="btn btn-outline-secondary logout-btn"
            onClick={handleLogout}
          >
            Logout
          </button>
        </div>
      </div>

      <div className="row justify-content-center">
        <div className="col-12 col-lg-10">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h3 className="text-success">Your Medications</h3>
            <button 
              className="dosebuddy-btn-primary btn"
              onClick={handleOpenModal}
            >
              + Add Medication
            </button>
          </div>

          {medicines.length === 0 ? (
            <div className="text-center py-5">
              <h4 className="text-muted">No medications added yet</h4>
              <p className="text-muted">Add your first medication to get started</p>
            </div>
          ) : (
            <div className="medicine-grid">
              {medicines.map(medicine => (
                <div key={medicine.id} className="medicine-card card shadow-sm">
                  <div className="card-body">
                    <div className="d-flex justify-content-between align-items-start mb-2">
                      <h5 className="card-title text-success">{medicine.name}</h5>
                      <button 
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleDeleteMedicine(medicine.id)}
                      >
                        ×
                      </button>
                    </div>
                    <p className="card-text">
                      <strong>Dosage:</strong> {medicine.dosage}<br/>
                      <strong>Frequency:</strong> {medicine.frequency}<br/>
                      <strong>Time:</strong> {medicine.time}<br/>
                      <strong>Last Taken:</strong> {medicine.lastTaken}
                    </p>
                    <button 
                      className="dosebuddy-btn-primary btn btn-sm w-100"
                      onClick={() => handleMarkAsTaken(medicine.id)}
                    >
                      Mark as Taken
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Medicine Modal */}
      {showAddMedicine && (
        <div className="modal show d-block" tabIndex="-1" style={{backgroundColor: 'rgba(0,0,0,0.5)'}}>
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content dosebuddy-modal">
              <div className="modal-header">
                <h5 className="modal-title">Add New Medication</h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={handleCloseModal}
                ></button>
              </div>
              <div className="modal-body">
                <div className="mb-3">
                  <label className="form-label">Medicine Name</label>
                  <input 
                    ref={nameRef}
                    type="text" 
                    className="form-control"
                    placeholder="Enter medicine name"
                    required 
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Dosage</label>
                  <input 
                    ref={dosageRef}
                    type="text" 
                    className="form-control"
                    placeholder="e.g., 500mg, 1 tablet"
                    required 
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Frequency</label>
                  <input 
                    ref={frequencyRef}
                    type="text" 
                    className="form-control"
                    placeholder="e.g., Once daily, Twice daily"
                    required 
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Time</label>
                  <input 
                    ref={timeRef}
                    type="text" 
                    className="form-control"
                    placeholder="e.g., 8:00 AM, After meals"
                    required 
                  />
                </div>
                <div className="d-flex gap-2">
                  <button 
                    type="button" 
                    className="dosebuddy-btn-primary btn flex-fill"
                    onClick={handleAddMedicine}
                  >
                    Add Medication
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-secondary flex-fill"
                    onClick={handleCloseModal}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="app-container">
      <div className="dosebuddy-container">
        {!isAuthenticated ? (
          showRegister ? <RegisterForm /> : <LoginForm />
        ) : (
          <Dashboard />
        )}
      </div>
    </div>
  );
}

export default App